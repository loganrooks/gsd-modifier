Date: 2026-04-22
Status: active inventory

# Artifact Inventory

## Purpose

- [g:r:i] This file is the denser artifact-discovery surface for the workspace.
- [d:r:i] Use [INDEX.md](INDEX.md) for the controlled entry path and short read order.
- [d:r:i] Use this file when you need to find where a family, lane, artifact cluster, or active reference surface actually lives.

## Source-Of-Truth Hierarchy

- charter and governing posture: `AUDIT-CHARTER.md`
- authority / artifact-class map for this directory: `WORKSPACE-AUTHORITY-AND-ORGANIZATION.md`
- governance-doc role and update protocol: `GOVERNANCE-READING-AND-UPDATE-PROTOCOL.md`
- current short governing synthesis: `CURRENT-STATE.md`
- current longer cumulative trace: `CURRENT-STATE-TRACE.md`
- live mutable state for this audit setup: `STATUS.md`
- onboarding read path for later reviewers: `ONBOARDING.md`
- primary distilled record of session-added framing: `SESSION-FRAMING-BRIEF.md`
- substantive questions and required output shapes: `QUESTION-SET.md`
- corpus split, packeting, and sizing discipline: `EVIDENCE-ARCHITECTURE.md`
- competing audit-program shapes and recommended main path: `PLAN-PROPOSALS.md`

## Active Family Baselines

### Main-Wave And Rerun Program

- main-wave design artifact: `MAIN-WAVE-LAUNCH-CONTRACT-AND-PACKET.md`
- contract-level cross-review outputs:
  - `lane-05-opus47-max-main-wave-contract-cross-review.md`
  - `lane-05-gpt54-xhigh-main-wave-contract-cross-review.md`
  - `lane-05-comparative-disposition.md`
- Wave-1 packet companion: `WAVE-1-PACKET-MANIFESTS.md`
- Wave-1 topology: `wave-1/README.md`
- Wave-2 topology: `wave-2/README.md`
- current accepted Wave-2 program-selection artifacts:
  - `wave-2/dispositions/06-wave-2-lane06-comparative-disposition.md`
  - `intervention-proposals/25-rerun-floor-recomputation.md`
  - `intervention-proposals/26-brake-exit-rule.md`
  - `intervention-proposals/27-preserve-only-activation-trigger-doctrine.md`
  - `intervention-proposals/28-execution-capacity-reopen-rule.md`

### Docs And Harness Intervention Layer

- `HARNESS-INTERVENTION-UPDATE-LANE.md`
- `HARNESS-INTERVENTION-ONBOARDING.md`
- `PR-DOCS-INTERVENTION-CARRY-AUDIT.md`
- `PR-DOCS-INTERVENTION-TRANSFORMATION-PLAN.md`
- `RUNTIME-MATERIALIZATION-AND-AUTHORITY.md`
- `GOAL-TO-SURFACE-INTERVENTION-INDEX.md`
- `SURFACE-STATUS-AND-DELTA.md`
- `docs-audit/`
- `tranche-audit/`

### Long-Horizon And Threshold Carry

- `intervention-proposals/29-long-horizon-carry-gap-register.md`
- `long-horizon-audit/`
- `threshold-audit/`
- `threshold-audit/dispositions/03-threshold-scanner-side-effects-internal-audit.md`
- `threshold-audit/outputs/04-scanner-side-effects-internal-audit-review-gpt54-xhigh-r1.md`
- `threshold-audit/dispositions/04-scanner-side-effects-internal-audit-review-inheritance.md`
- `threshold-audit/outputs/05-historical-scanner-influenced-reread-gpt54-xhigh-r1.md`
- `threshold-audit/dispositions/05-historical-scanner-influenced-reread-inheritance.md`

### Harness Improvement Full-Field Audit

- `harness-improvement-audit/README.md`
- `harness-improvement-audit/01-harness-maximal-improvement-opening-note.md`
- `harness-improvement-audit/packets/01-harness-maximal-improvement-field-map-packet.md`
- `harness-improvement-audit/specs/01-harness-maximal-improvement-field-map-spec.md`
- `harness-improvement-audit/prompts/01-harness-maximal-improvement-field-map-opus47-max-r1-launch-prompt.md`
- `harness-improvement-audit/launch-truth/01-harness-maximal-improvement-field-map-launch-truth.md`
- `harness-improvement-audit/outputs/01-harness-maximal-improvement-field-map-opus47-max-r1.md`
- `harness-improvement-audit/dispositions/01-harness-maximal-improvement-field-map-inheritance.md`
- `harness-improvement-audit/artifacts/01-harness-quality-canary-report.json`
- `intervention-proposals/45-harness-improvement-follow-through-sequencing.md`
- `intervention-proposals/46-harness-quality-canary-and-invariant-assertion-proposal.md`
- `intervention-proposals/47-audit-program-infrastructure-canon-absorption-and-aging-proposal.md`
- `intervention-proposals/48-harness-self-improvement-register-and-quality-basket-proposal.md`
- `intervention-proposals/49-harness-quality-canary-first-slice-implementation.md`
- `.planning/HARNESS-IMPROVEMENT-REGISTER.md`
- `intervention-proposals/50-harness-self-improvement-register-first-slice-implementation.md`
- `AUDIT-LANE-PATTERN-LIBRARY.md`
- `AUDIT-CANON-ABSORPTION-PROTOCOL.md`
- `AUDIT-SUBTREE-AGING-AND-GRADUATION.md`
- `AUDIT-SUBTREE-STATUS-REGISTER.md`
- `intervention-proposals/51-audit-program-infrastructure-first-slice-implementation.md`
- `intervention-proposals/52-audit-subtree-status-first-application.md`
- `intervention-proposals/53-verifier-lifecycle-carry-first-slice-proposal.md`
- `intervention-proposals/54-verifier-lifecycle-carry-first-slice-implementation.md`
- `intervention-proposals/55-setup-portable-gsd-robustness-and-reinstall-truth-proposal.md`
- `intervention-proposals/56-setup-portable-gsd-robustness-and-reinstall-truth-implementation.md`
- `intervention-proposals/57-transition-lifecycle-carry-first-slice-proposal.md`
- `intervention-proposals/58-transition-lifecycle-carry-first-slice-implementation.md`
- `intervention-proposals/59-milestone-boundary-lifecycle-carry-first-slice-proposal.md`
- `intervention-proposals/60-milestone-boundary-lifecycle-carry-first-slice-implementation.md`
- `intervention-proposals/61-state-progress-and-resume-future-carry-consumer-proposal.md`
- `intervention-proposals/62-state-progress-and-resume-future-carry-consumer-implementation.md`
- `intervention-proposals/63-spec-lifecycle-carry-first-slice-proposal.md`
- `intervention-proposals/64-spec-lifecycle-carry-first-slice-implementation.md`
- `intervention-proposals/65-read-packet-and-relevance-control-first-slice-proposal.md`
- `intervention-proposals/66-read-packet-and-relevance-control-first-slice-implementation.md`
- `intervention-proposals/67-initialization-and-ingest-read-packet-first-slice-proposal.md`
- `intervention-proposals/68-initialization-and-ingest-read-packet-first-slice-implementation.md`
- `intervention-proposals/69-health-and-migration-follow-through-first-slice-proposal.md`
- `intervention-proposals/70-health-and-migration-follow-through-first-slice-implementation.md`
- `intervention-proposals/71-update-follow-through-first-slice-proposal.md`
- `intervention-proposals/72-update-follow-through-first-slice-implementation.md`
- `intervention-proposals/73-seed-consumer-carry-first-slice-proposal.md`
- `intervention-proposals/74-seed-consumer-carry-first-slice-implementation.md`
- `intervention-proposals/75-explore-seed-producer-convergence-first-slice-proposal.md`
- `intervention-proposals/76-explore-seed-producer-convergence-first-slice-implementation.md`
- `intervention-proposals/77-seed-doctrine-vintage-anchor-first-slice-proposal.md`
- `intervention-proposals/78-seed-doctrine-vintage-anchor-first-slice-implementation.md`
- `intervention-proposals/79-uplift-side-seed-corpus-posture-first-slice-proposal.md`
- `intervention-proposals/80-uplift-side-seed-corpus-posture-first-slice-implementation.md`
- `intervention-proposals/81-seed-operator-consumer-widening-first-slice-proposal.md`
- `intervention-proposals/82-seed-operator-consumer-widening-first-slice-implementation.md`
- `intervention-proposals/83-seed-audit-gate-widening-first-slice-proposal.md`
- `intervention-proposals/84-seed-audit-gate-widening-first-slice-implementation.md`
- `intervention-proposals/85-legacy-seed-corpus-migration-detect-only-first-slice-proposal.md`
- `intervention-proposals/86-legacy-seed-corpus-migration-detect-only-first-slice-implementation.md`
- `intervention-proposals/87-seed-migration-detect-only-harden-follow-through-proposal.md`
- `intervention-proposals/88-seed-migration-detect-only-harden-follow-through-implementation.md`
- `intervention-proposals/89-seed-migration-operator-facing-pointer-bridge-proposal.md`
- `intervention-proposals/90-seed-migration-operator-facing-pointer-bridge-implementation.md`
- `intervention-proposals/91-seed-migration-pointer-bridge-harden-follow-through-proposal.md`
- `intervention-proposals/92-seed-migration-pointer-bridge-harden-follow-through-implementation.md`
- `intervention-proposals/93-uplift-agent-assist-and-propagation-baseline-split-note.md`
- `intervention-proposals/94-propagation-baseline-delta-split-first-follow-through-proposal.md`
- `intervention-proposals/95-upstream-pristine-propagation-baseline-first-slice.md`
- `intervention-proposals/96-repo-local-propagation-delta-first-slice.md`

### Self-Overcoming Family

- `intervention-proposals/32-strengthening-opportunity-first-slice-implementation.md`
- `intervention-proposals/33-research-and-planner-strengthening-carry-follow-through.md`
- `intervention-proposals/34-strengthening-opportunity-benchmark-packet.md`
- `intervention-proposals/35-strengthening-opportunity-reference-surface.md`
- `self-overcoming-audit/`

### Entry-Surface / Project-Uplift Family

- `intervention-proposals/36-initialization-onboarding-and-project-uplift-strengthening-plan.md`
- `intervention-proposals/37-entry-surface-and-project-uplift-map.md`
- `intervention-proposals/38-entry-surface-concern-and-carrier-placement-map.md`
- `intervention-proposals/39-project-uplift-workflow-proposal.md`
- `intervention-proposals/40-project-uplift-first-slice-implementation.md`
- `intervention-proposals/42-project-uplift-signal-layer-harden-slice.md`
- `intervention-proposals/43-project-uplift-compatibility-anchor-slice.md`
- `intervention-proposals/44-project-uplift-compatibility-consumer-follow-through.md`
- `intervention-proposals/116-uplift-compatibility-annotation-first-slice-implementation.md`
- `intervention-proposals/118-uplift-consumer-chain-asymmetry-next-proposal.md`
- `intervention-proposals/119-uplift-consumer-chain-asymmetry-classification-return.md`
- `intervention-proposals/120-transition-state-uplift-continuity-first-slice-proposal.md`
- `intervention-proposals/121-transition-state-uplift-continuity-first-slice-implementation.md`
- `intervention-proposals/122-milestone-boundary-uplift-shared-reference-first-slice-proposal.md`
- `propagation-audit/44-transition-state-uplift-continuity-change-triggered-refresh.md`
- repo-local uplift outputs:
  - `.planning/UPLIFT-REPORT.md`
  - `.planning/UPLIFT-MANIFEST.json`
  - `Project Uplift` section in `.planning/STATE.md`
- challenge subtree: `entry-uplift-audit/`

### Contract Propagation / Dependency-Carry Family

- `intervention-proposals/41-contract-propagation-and-dependency-carry-audit-seed.md`
- `propagation-audit/README.md`
- `propagation-audit/01-contract-propagation-and-dependency-carry-opening-note.md`
- `propagation-audit/02-project-uplift-producer-consumer-and-impact-map.md`
- `propagation-audit/03-resume-project-second-consumer-follow-through-proposal.md`
- `propagation-audit/04-resume-project-second-consumer-implementation.md`
- `propagation-audit/packets/01-propagation-chain-reread-packet.md`
- `propagation-audit/specs/01-propagation-chain-reread-spec.md`
- `propagation-audit/prompts/01-propagation-chain-reread-opus47-max-r1-launch-prompt.md`
- `propagation-audit/launch-truth/01-propagation-chain-reread-launch-truth.md`
- `propagation-audit/outputs/01-propagation-chain-reread-opus47-max-r1.md`
- `propagation-audit/dispositions/01-propagation-chain-reread-inheritance.md`
- `propagation-audit/05-project-uplift-chain-map.md`
- `propagation-audit/06-bounded-propagation-strengthening-batch-a-b-d-e-f.md`
- `propagation-audit/07-overlay-add-vs-overwrite-contract-and-post-materialization-gate.md`
- `propagation-audit/08-broader-network-producer-consumer-and-carrier-map.md`
- `propagation-audit/packets/02-broader-network-propagation-field-mapping-packet.md`
- `propagation-audit/specs/02-broader-network-propagation-field-mapping-spec.md`
- `propagation-audit/prompts/02-broader-network-propagation-field-mapping-opus47-max-r1-launch-prompt.md`
- `propagation-audit/launch-truth/02-broader-network-propagation-field-mapping-launch-truth.md`
- `propagation-audit/outputs/02-broader-network-propagation-field-mapping-opus47-max-r1.md`
- `propagation-audit/dispositions/02-broader-network-propagation-field-mapping-inheritance.md`
- `propagation-audit/09-sharpened-propagation-field-split.md`
- `propagation-audit/10-model-policy-three-surface-invariant.md`
- `propagation-audit/11-upstream-pristine-frontier-propagation-obligation.md`
- `propagation-audit/12-cross-family-edge-supplement.md`
- `propagation-audit/13-machine-readable-propagation-registry-first-slice.md`
- `propagation-audit/14-propagation-registry-generation-and-seeding-policy.md`
- `propagation-audit/15-propagation-registry-v2-layered-first-refresh.md`
- `propagation-audit/16-compatibility-anchor-change-triggered-refresh.md`
- `propagation-audit/17-compatibility-consumer-follow-through-refresh.md`
- `propagation-audit/18-threshold-scanner-change-triggered-refresh.md`
- `propagation-audit/19-verifier-lifecycle-carry-change-triggered-refresh.md`
- `propagation-audit/20-setup-portable-gsd-robustness-change-triggered-refresh.md`
- `propagation-audit/21-transition-lifecycle-carry-change-triggered-refresh.md`
- `propagation-audit/22-milestone-boundary-lifecycle-carry-change-triggered-refresh.md`
- `propagation-audit/23-state-progress-and-resume-future-carry-change-triggered-refresh.md`
- `propagation-audit/24-spec-lifecycle-carry-change-triggered-refresh.md`
- `propagation-audit/25-read-packet-and-relevance-control-change-triggered-refresh.md`
- `propagation-audit/26-initialization-and-ingest-read-packet-change-triggered-refresh.md`
- `propagation-audit/27-health-and-migration-follow-through-change-triggered-refresh.md`
- `propagation-audit/28-update-follow-through-change-triggered-refresh.md`
- `propagation-audit/29-seed-consumer-carry-change-triggered-refresh.md`
- `propagation-audit/30-explore-seed-producer-convergence-change-triggered-refresh.md`
- `propagation-audit/31-seed-doctrine-vintage-anchor-change-triggered-refresh.md`
- `propagation-audit/32-uplift-seed-corpus-posture-change-triggered-refresh.md`
- `propagation-audit/33-seed-operator-consumer-widening-change-triggered-refresh.md`
- `propagation-audit/34-seed-audit-gate-widening-change-triggered-refresh.md`
- `propagation-audit/35-legacy-seed-corpus-migration-detect-only-change-triggered-refresh.md`
- `propagation-audit/36-seed-migration-detect-only-harden-change-triggered-refresh.md`
- `propagation-audit/37-seed-migration-operator-facing-pointer-change-triggered-refresh.md`
- `propagation-audit/38-seed-migration-pointer-bridge-harden-change-triggered-refresh.md`
- `propagation-audit/43-uplift-compatibility-annotation-change-triggered-refresh.md`
- `propagation-audit/39-propagation-review-route-change-triggered-refresh.md`
- `propagation-audit/40-propagation-review-route-harden-change-triggered-refresh.md`
- `propagation-audit/44-transition-state-uplift-continuity-change-triggered-refresh.md`
- `propagation-audit/launch-truth/07-propagation-review-route-reread-launch-truth.md`
- `propagation-audit/outputs/07-propagation-review-route-reread-opus47-max-r1.md`
- `propagation-audit/dispositions/07-propagation-review-route-reread-inheritance.md`
- `propagation-audit/packets/06-seed-migration-pointer-bridge-harden-reread-packet.md`
- `propagation-audit/specs/06-seed-migration-pointer-bridge-harden-reread-spec.md`
- `propagation-audit/prompts/06-seed-migration-pointer-bridge-harden-reread-opus47-max-r1-launch-prompt.md`
- `propagation-audit/launch-truth/06-seed-migration-pointer-bridge-harden-reread-launch-truth.md`
- `propagation-audit/outputs/06-seed-migration-pointer-bridge-harden-reread-opus47-max-r1.md`
- `propagation-audit/dispositions/06-seed-migration-pointer-bridge-harden-reread-inheritance.md`
- `propagation-audit/launch-truth/30-seed-doctrine-vintage-sidecar-launch-truth.md`
- `propagation-audit/outputs/04-seed-vintage-and-consumer-field-sidecar-gpt54-xhigh-r1.md`
- `propagation-audit/dispositions/04-seed-vintage-and-consumer-field-sidecar-inheritance.md`
- `propagation-audit/packets/04-seed-migration-detect-only-first-slice-reread-packet.md`
- `propagation-audit/specs/04-seed-migration-detect-only-first-slice-reread-spec.md`
- `propagation-audit/prompts/04-seed-migration-detect-only-first-slice-reread-opus47-max-r1-launch-prompt.md`
- `propagation-audit/launch-truth/04-seed-migration-detect-only-first-slice-reread-launch-truth.md`
- `propagation-audit/outputs/04-seed-migration-detect-only-first-slice-reread-opus47-max-r1.md`
- `propagation-audit/dispositions/04-seed-migration-detect-only-first-slice-reread-inheritance.md`
- `propagation-audit/packets/05-seed-migration-operator-facing-pointer-bridge-reread-packet.md`
- `propagation-audit/specs/05-seed-migration-operator-facing-pointer-bridge-reread-spec.md`
- `propagation-audit/prompts/05-seed-migration-operator-facing-pointer-bridge-reread-opus47-max-r1-launch-prompt.md`
- `propagation-audit/launch-truth/05-seed-migration-operator-facing-pointer-bridge-reread-launch-truth.md`
- `propagation-audit/outputs/05-seed-migration-operator-facing-pointer-bridge-reread-opus47-max-r1.md`
- `propagation-audit/dispositions/05-seed-migration-operator-facing-pointer-bridge-reread-inheritance.md`
- `propagation-audit/artifacts/01-propagation-field-registry-v1.json`
- `propagation-audit/artifacts/02-propagation-registry-v2-inventory-roster.json`
- `propagation-audit/artifacts/03-propagation-registry-v2-declared-contracts.json`
- `propagation-audit/artifacts/04-propagation-registry-v2-semantic-map.json`
- `propagation-audit/artifacts/05-propagation-registry-v2-evidence-index.json`
- `propagation-audit/artifacts/06-propagation-registry-v2-coverage-and-refresh.json`
- `propagation-audit/artifacts/07-seed-migration-manifest-shape-fixture.json`
- `intervention-proposals/95-upstream-pristine-propagation-baseline-first-slice.md`
- `intervention-proposals/96-repo-local-propagation-delta-first-slice.md`
- `intervention-proposals/97-propagation-review-route-first-slice-proposal.md`
- `intervention-proposals/98-propagation-review-route-first-slice-implementation.md`
- `intervention-proposals/99-propagation-review-route-harden-follow-through-proposal.md`
- `intervention-proposals/100-propagation-review-route-harden-follow-through-implementation.md`
- `intervention-proposals/101-repo-local-workflow-additions-and-propagation-map-orientation.md`
- `intervention-proposals/102-uplift-agent-assist-first-slice-proposal.md`
- `intervention-proposals/103-uplift-agent-assist-patterns.md`
- `intervention-proposals/104-uplift-docs-governance-classification-packet-template-proposal.md`
- `intervention-proposals/105-uplift-docs-governance-classification-packet-template-implementation.md`
- `intervention-proposals/106-uplift-docs-governance-classification-first-exercise.md`
- `intervention-proposals/107-uplift-carrier-gap-identification-second-exercise.md`
- `intervention-proposals/108-uplift-assist-route-pointer-first-slice-implementation.md`
- `intervention-proposals/109-uplift-docs-governance-runtime-proof-and-refresh.md`
- `intervention-proposals/110-uplift-cross-runtime-comparison-packet-template-proposal.md`
- `intervention-proposals/111-uplift-cross-runtime-comparison-packet-template-implementation.md`
- `intervention-proposals/112-uplift-cross-runtime-comparison-first-exercise.md`
- `intervention-proposals/113-uplift-cross-runtime-concern-family-split-next-move.md`
- `intervention-proposals/114-uplift-cross-runtime-compatibility-widening-shape-proposal.md`
- `intervention-proposals/115-harness-modifier-extraction-and-npx-distribution-route.md`
- `entry-uplift-audit/packets/06-uplift-docs-governance-classification-packet-template.md`
- `entry-uplift-audit/packets/07-uplift-docs-governance-classification-first-exercise-packet.md`
- `entry-uplift-audit/packets/12-uplift-cross-runtime-comparison-first-exercise-packet.md`
- `entry-uplift-audit/packets/13-uplift-cross-runtime-comparison-first-exercise-reread-packet.md`
- `entry-uplift-audit/packets/15-uplift-cross-runtime-compatibility-widening-shape-proposal-reread-packet.md`
- `entry-uplift-audit/outputs/06-uplift-docs-governance-classification-first-exercise.md`
- `entry-uplift-audit/outputs/10-uplift-cross-runtime-comparison-first-exercise.md`
- `entry-uplift-audit/outputs/11-uplift-cross-runtime-comparison-first-exercise-reread-opus47-max-r1.md`
- `entry-uplift-audit/outputs/13-uplift-cross-runtime-compatibility-widening-shape-proposal-reread-opus47-max-r1.md`
- `entry-uplift-audit/launch-truth/07-uplift-cross-runtime-comparison-first-exercise-reread-launch-truth.md`
- `entry-uplift-audit/launch-truth/08-uplift-cross-runtime-concern-family-split-launch-truth.md`
- `entry-uplift-audit/launch-truth/09-uplift-cross-runtime-compatibility-widening-shape-proposal-reread-launch-truth.md`
- `entry-uplift-audit/dispositions/06-uplift-docs-governance-classification-first-exercise-disposition.md`
- `entry-uplift-audit/dispositions/10-uplift-cross-runtime-comparison-first-exercise-disposition.md`
- `entry-uplift-audit/dispositions/11-uplift-cross-runtime-comparison-first-exercise-reread-inheritance.md`
- `entry-uplift-audit/dispositions/12-uplift-cross-runtime-concern-family-split-inheritance.md`
- `entry-uplift-audit/dispositions/13-uplift-cross-runtime-compatibility-widening-shape-proposal-reread-inheritance.md`
- `entry-uplift-audit/specs/09-uplift-cross-runtime-compatibility-widening-shape-proposal-reread-spec.md`
- `entry-uplift-audit/prompts/09-uplift-cross-runtime-compatibility-widening-shape-proposal-reread-opus47-max-r1-launch-prompt.md`
- `entry-uplift-audit/specs/07-uplift-cross-runtime-comparison-first-exercise-reread-spec.md`
- `entry-uplift-audit/prompts/07-uplift-cross-runtime-comparison-first-exercise-reread-opus47-max-r1-launch-prompt.md`
- `entry-uplift-audit/launch-truth/06-uplift-assist-post-first-exercise-next-move-launch-truth.md`
- `entry-uplift-audit/outputs/07-uplift-assist-post-first-exercise-next-move-opus47-max-r1.md`
- `entry-uplift-audit/dispositions/07-uplift-assist-post-first-exercise-next-move-inheritance.md`
- `entry-uplift-audit/packets/08-uplift-carrier-gap-identification-packet-template.md`
- `entry-uplift-audit/packets/09-uplift-carrier-gap-identification-second-exercise-packet.md`
- `entry-uplift-audit/packets/10-uplift-docs-governance-classification-runtime-proof-packet.md`
- `entry-uplift-audit/packets/11-uplift-cross-runtime-comparison-packet-template.md`
- `entry-uplift-audit/outputs/08-uplift-carrier-gap-identification-second-exercise.md`
- `entry-uplift-audit/outputs/09-uplift-docs-governance-classification-runtime-proof.md`
- `entry-uplift-audit/dispositions/08-uplift-carrier-gap-identification-second-exercise-disposition.md`
- `entry-uplift-audit/dispositions/09-uplift-docs-governance-classification-runtime-proof-disposition.md`
- `propagation-audit/41-uplift-assist-route-pointer-change-triggered-refresh.md`
- `propagation-audit/42-uplift-docs-governance-runtime-proof-change-triggered-refresh.md`

## Challenge And Output Subtrees

- `docs-audit/`
- `tranche-audit/`
- `long-horizon-audit/`
- `threshold-audit/`
- `self-overcoming-audit/`
- `entry-uplift-audit/`
- `propagation-audit/`
- `wave-1/`
- `wave-2/`
- `corpus/`

## Generated And Structured Artifacts

- selected runtime-visibility artifacts:
  - `tranche-audit/artifacts/01-runtime-visibility-report.json`
  - `intervention-proposals/artifacts/01-second-tranche-clean-boundary-runtime-visibility-snapshot.json`
  - `intervention-proposals/artifacts/02-manifest-install-coherence-report.json`
  - `intervention-proposals/artifacts/03-gsd-code-reviewer-post-carry-runtime-visibility.json`
  - `intervention-proposals/artifacts/04-gsd-code-fixer-post-carry-runtime-visibility.json`
  - `intervention-proposals/artifacts/05-gsd-intel-updater-post-carry-runtime-visibility.json`
  - `intervention-proposals/artifacts/06-gsd-pattern-mapper-post-carry-runtime-visibility.json`
- launch history:
  - `LAUNCH-LEDGER.md`

## How To Use This Inventory

- [d:r:i] If you need the shortest legitimate re-entry, do not start here. Start with [INDEX.md](INDEX.md), then [CURRENT-STATE.md](CURRENT-STATE.md).
- [d:r:i] If you need to find where a family or artifact cluster lives, use this file.
- [d:r:i] If you need mutable next steps, use [STATUS.md](STATUS.md) rather than reading this inventory as a queue.
